// Browser compatibility utilities for NYC Data Analyzer

/**
 * Detect browser and version
 * @returns {Object} Browser information
 */
const detectBrowser = () => {
  const userAgent = navigator.userAgent;
  let browserName = "Unknown";
  let browserVersion = "Unknown";
  
  // Detect Chrome
  if (userAgent.match(/chrome|chromium|crios/i)) {
    browserName = "Chrome";
    const match = userAgent.match(/(?:chrome|chromium|crios)\/(\d+)/i);
    if (match) browserVersion = match[1];
  } 
  // Detect Firefox
  else if (userAgent.match(/firefox|fxios/i)) {
    browserName = "Firefox";
    const match = userAgent.match(/(?:firefox|fxios)\/(\d+)/i);
    if (match) browserVersion = match[1];
  } 
  // Detect Safari
  else if (userAgent.match(/safari/i) && !userAgent.match(/chrome|chromium|crios/i)) {
    browserName = "Safari";
    const match = userAgent.match(/version\/(\d+)/i);
    if (match) browserVersion = match[1];
  } 
  // Detect Edge
  else if (userAgent.match(/edg/i)) {
    browserName = "Edge";
    const match = userAgent.match(/edg\/(\d+)/i);
    if (match) browserVersion = match[1];
  } 
  // Detect IE
  else if (userAgent.match(/trident/i)) {
    browserName = "Internet Explorer";
    const match = userAgent.match(/(?:msie |rv:)(\d+)/i);
    if (match) browserVersion = match[1];
  }
  
  return {
    name: browserName,
    version: browserVersion,
    userAgent: userAgent,
    isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)
  };
};

/**
 * Check if browser supports specific features
 * @returns {Object} Feature support information
 */
const checkFeatureSupport = () => {
  return {
    flexbox: typeof document.createElement('div').style.flexBasis !== 'undefined',
    grid: typeof document.createElement('div').style.grid !== 'undefined',
    es6: typeof Symbol !== 'undefined' && typeof Symbol.iterator !== 'undefined',
    fetch: typeof fetch !== 'undefined',
    serviceWorker: 'serviceWorker' in navigator,
    webGL: (() => {
      try {
        const canvas = document.createElement('canvas');
        return !!(window.WebGLRenderingContext && 
          (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
      } catch (e) {
        return false;
      }
    })(),
    webP: (() => {
      const elem = document.createElement('canvas');
      if (elem.getContext && elem.getContext('2d')) {
        return elem.toDataURL('image/webp').indexOf('data:image/webp') === 0;
      }
      return false;
    })(),
    localStorage: (() => {
      try {
        return 'localStorage' in window && window['localStorage'] !== null;
      } catch (e) {
        return false;
      }
    })()
  };
};

/**
 * Apply polyfills for older browsers
 */
const applyPolyfills = () => {
  // Polyfill for Array.from
  if (!Array.from) {
    Array.from = function(arrayLike) {
      return Array.prototype.slice.call(arrayLike);
    };
  }
  
  // Polyfill for Object.assign
  if (typeof Object.assign !== 'function') {
    Object.assign = function(target) {
      if (target === null || target === undefined) {
        throw new TypeError('Cannot convert undefined or null to object');
      }
      const to = Object(target);
      for (let i = 1; i < arguments.length; i++) {
        const nextSource = arguments[i];
        if (nextSource !== null && nextSource !== undefined) {
          for (const nextKey in nextSource) {
            if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
              to[nextKey] = nextSource[nextKey];
            }
          }
        }
      }
      return to;
    };
  }
  
  // Polyfill for Promise
  if (typeof window.Promise !== 'function') {
    console.warn('Promise polyfill would be applied in a production environment');
    // In a real app, we would include a Promise polyfill here
  }
};

/**
 * Get recommended browser settings based on detected browser
 * @returns {Object} Recommended settings
 */
const getRecommendedSettings = () => {
  const browser = detectBrowser();
  const features = checkFeatureSupport();
  
  let recommendations = [];
  
  if (browser.name === "Internet Explorer") {
    recommendations.push("We recommend upgrading to a modern browser like Chrome, Firefox, or Edge for the best experience.");
  }
  
  if (!features.flexbox || !features.grid) {
    recommendations.push("Your browser may not fully support modern CSS layouts. Some visual elements might not display correctly.");
  }
  
  if (!features.es6) {
    recommendations.push("Your browser may not support modern JavaScript features. Some functionality might be limited.");
  }
  
  if (!features.localStorage) {
    recommendations.push("Your browser does not support local storage. User preferences will not be saved between sessions.");
  }
  
  return {
    browser: browser,
    features: features,
    recommendations: recommendations
  };
};

// Export utilities
export {
  detectBrowser,
  checkFeatureSupport,
  applyPolyfills,
  getRecommendedSettings
};
