// Performance optimization utilities for NYC Data Analyzer

/**
 * Implements a simple memoization cache for expensive function calls
 * @param {Function} fn - The function to memoize
 * @returns {Function} - Memoized function
 */
const memoize = (fn) => {
  const cache = new Map();
  return (...args) => {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      return cache.get(key);
    }
    const result = fn(...args);
    cache.set(key, result);
    return result;
  };
};

/**
 * Debounces a function to limit how often it can be called
 * @param {Function} fn - The function to debounce
 * @param {number} delay - Delay in milliseconds
 * @returns {Function} - Debounced function
 */
const debounce = (fn, delay) => {
  let timeoutId;
  return (...args) => {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    timeoutId = setTimeout(() => {
      fn(...args);
    }, delay);
  };
};

/**
 * Throttles a function to limit how often it can be called
 * @param {Function} fn - The function to throttle
 * @param {number} limit - Limit in milliseconds
 * @returns {Function} - Throttled function
 */
const throttle = (fn, limit) => {
  let lastCall = 0;
  return (...args) => {
    const now = Date.now();
    if (now - lastCall >= limit) {
      lastCall = now;
      fn(...args);
    }
  };
};

/**
 * Chunks an array into smaller arrays of specified size
 * @param {Array} array - The array to chunk
 * @param {number} size - Size of each chunk
 * @returns {Array} - Array of chunks
 */
const chunkArray = (array, size) => {
  const chunked = [];
  for (let i = 0; i < array.length; i += size) {
    chunked.push(array.slice(i, i + size));
  }
  return chunked;
};

/**
 * Lazy loads data when element is in viewport
 * @param {Function} callback - Function to call when element is in viewport
 * @returns {Function} - Function to attach to ref
 */
const useLazyLoad = (callback) => {
  return (node) => {
    if (node) {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            callback();
            observer.disconnect();
          }
        });
      });
      observer.observe(node);
    }
  };
};

/**
 * Implements a simple LRU cache for API responses
 */
class LRUCache {
  constructor(capacity) {
    this.capacity = capacity;
    this.cache = new Map();
  }

  get(key) {
    if (!this.cache.has(key)) return null;
    
    // Get value and refresh position
    const value = this.cache.get(key);
    this.cache.delete(key);
    this.cache.set(key, value);
    return value;
  }

  put(key, value) {
    // Remove if exists
    if (this.cache.has(key)) {
      this.cache.delete(key);
    }
    
    // Evict oldest if at capacity
    if (this.cache.size >= this.capacity) {
      const oldestKey = this.cache.keys().next().value;
      this.cache.delete(oldestKey);
    }
    
    // Add new entry
    this.cache.set(key, value);
  }
}

// Export utilities
module.exports = {
  memoize,
  debounce,
  throttle,
  chunkArray,
  useLazyLoad,
  LRUCache
};
