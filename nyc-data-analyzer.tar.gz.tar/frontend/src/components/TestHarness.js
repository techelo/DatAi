import React, { useState } from 'react';
import axios from 'axios';
import { 
  Box, 
  Typography, 
  Button, 
  Paper, 
  Grid,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress
} from '@mui/material';

const TestHarness = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [testEndpoint, setTestEndpoint] = useState('http://localhost:5000/api/test/odata');
  const [testDataset, setTestDataset] = useState('housingViolations');
  const [testResults, setTestResults] = useState(null);
  const [testStatus, setTestStatus] = useState('');

  // Test OData connection
  const testODataConnection = async () => {
    setLoading(true);
    setError(null);
    setTestStatus('Testing OData connection...');
    
    try {
      const response = await axios.get(testEndpoint, {
        params: { dataset: testDataset }
      });
      
      setTestResults(response.data);
      setTestStatus('OData connection test successful!');
    } catch (err) {
      setError(err.response?.data?.message || 'Error testing OData connection');
      setTestStatus('OData connection test failed.');
    } finally {
      setLoading(false);
    }
  };

  // Test data retrieval
  const testDataRetrieval = async () => {
    setLoading(true);
    setError(null);
    setTestStatus('Testing data retrieval...');
    
    try {
      const response = await axios.get('http://localhost:5000/api/test/data', {
        params: { dataset: testDataset }
      });
      
      setTestResults(response.data);
      setTestStatus('Data retrieval test successful!');
    } catch (err) {
      setError(err.response?.data?.message || 'Error testing data retrieval');
      setTestStatus('Data retrieval test failed.');
    } finally {
      setLoading(false);
    }
  };

  // Test AI integration
  const testAIIntegration = async () => {
    setLoading(true);
    setError(null);
    setTestStatus('Testing AI integration...');
    
    try {
      const response = await axios.post('http://localhost:5000/api/ai/chat', {
        messages: [{ sender: 'user', text: 'Analyze housing violations in Brooklyn' }],
        odataEndpoint: testEndpoint
      });
      
      setTestResults(response.data);
      setTestStatus('AI integration test successful!');
    } catch (err) {
      setError(err.response?.data?.message || 'Error testing AI integration');
      setTestStatus('AI integration test failed.');
    } finally {
      setLoading(false);
    }
  };

  // Run all tests
  const runAllTests = async () => {
    setLoading(true);
    setError(null);
    setTestStatus('Running all tests...');
    
    try {
      // Test 1: OData connection
      setTestStatus('Test 1/3: Testing OData connection...');
      const odataResponse = await axios.get(testEndpoint, {
        params: { dataset: testDataset }
      });
      
      // Test 2: Data retrieval
      setTestStatus('Test 2/3: Testing data retrieval...');
      const dataResponse = await axios.get('http://localhost:5000/api/test/data', {
        params: { dataset: testDataset }
      });
      
      // Test 3: AI integration
      setTestStatus('Test 3/3: Testing AI integration...');
      const aiResponse = await axios.post('http://localhost:5000/api/ai/chat', {
        messages: [{ sender: 'user', text: 'Analyze housing violations in Brooklyn' }],
        odataEndpoint: testEndpoint
      });
      
      setTestResults({
        odataTest: odataResponse.data,
        dataTest: dataResponse.data,
        aiTest: aiResponse.data
      });
      
      setTestStatus('All tests completed successfully!');
    } catch (err) {
      setError(err.response?.data?.message || 'Error running tests');
      setTestStatus('Test suite failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Test Harness
      </Typography>
      
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Test the NYC Data Analyzer application with sample data
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper elevation={2} sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Test Configuration
            </Typography>
            
            <TextField
              fullWidth
              label="Test Endpoint"
              value={testEndpoint}
              onChange={(e) => setTestEndpoint(e.target.value)}
              margin="normal"
            />
            
            <FormControl fullWidth margin="normal">
              <InputLabel>Test Dataset</InputLabel>
              <Select
                value={testDataset}
                label="Test Dataset"
                onChange={(e) => setTestDataset(e.target.value)}
              >
                <MenuItem value="housingViolations">Housing Violations</MenuItem>
                <MenuItem value="dobViolations">DOB Violations</MenuItem>
                <MenuItem value="plutoData">PLUTO Data</MenuItem>
              </Select>
            </FormControl>
            
            <Box sx={{ mt: 3, display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Button 
                variant="contained" 
                color="primary"
                onClick={testODataConnection}
                disabled={loading}
              >
                Test OData Connection
              </Button>
              
              <Button 
                variant="contained" 
                color="secondary"
                onClick={testDataRetrieval}
                disabled={loading}
              >
                Test Data Retrieval
              </Button>
              
              <Button 
                variant="contained" 
                color="info"
                onClick={testAIIntegration}
                disabled={loading}
              >
                Test AI Integration
              </Button>
              
              <Button 
                variant="contained" 
                color="success"
                onClick={runAllTests}
                disabled={loading}
              >
                Run All Tests
              </Button>
            </Box>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={8}>
          <Paper elevation={2} sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Test Results
            </Typography>
            
            {loading && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                <CircularProgress size={24} />
                <Typography>{testStatus}</Typography>
              </Box>
            )}
            
            {error && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {error}
              </Alert>
            )}
            
            {!loading && testStatus && !error && (
              <Alert severity="success" sx={{ mb: 2 }}>
                {testStatus}
              </Alert>
            )}
            
            {testResults && (
              <Box sx={{ mt: 2, p: 2, bgcolor: '#f5f5f5', borderRadius: 1, overflow: 'auto', maxHeight: '500px' }}>
                <pre>{JSON.stringify(testResults, null, 2)}</pre>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default TestHarness;
