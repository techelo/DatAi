import React, { useState } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip
} from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import WarningIcon from '@mui/icons-material/Warning';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ApartmentIcon from '@mui/icons-material/Apartment';
import ReportProblemIcon from '@mui/icons-material/ReportProblem';

const Dashboard = () => {
  // In a real app, this data would come from the backend
  const [stats] = useState({
    totalViolations: 12500,
    openViolations: 8700,
    resolvedViolations: 3800,
    criticalViolations: 2300,
    recentTrend: 'down',
    trendPercentage: 12,
    topAreas: [
      { name: 'Queens', count: 4200, percentage: 33.6 },
      { name: 'Brooklyn', count: 3800, percentage: 30.4 },
      { name: 'Manhattan', count: 2500, percentage: 20.0 },
      { name: 'Bronx', count: 1600, percentage: 12.8 },
      { name: 'Staten Island', count: 400, percentage: 3.2 }
    ],
    violationTypes: [
      { type: 'Heat/Hot Water', count: 3200, severity: 'high' },
      { type: 'Plumbing', count: 2800, severity: 'medium' },
      { type: 'Paint/Plaster', count: 2300, severity: 'low' },
      { type: 'Electric', count: 1900, severity: 'high' },
      { type: 'Pests', count: 1500, severity: 'medium' }
    ],
    recentInsights: [
      'Heat/Hot Water violations increased by 15% in Queens during winter months',
      'Buildings in Brooklyn have shown a 22% decrease in electrical violations after recent inspections',
      'The Bronx has the highest concentration of critical violations per building',
      'Manhattan high-rises show consistent plumbing issues in buildings over 50 years old'
    ]
  });

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Dashboard
      </Typography>
      
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Overview of NYC housing violations data and insights
      </Typography>
      
      <Grid container spacing={3}>
        {/* Summary Cards */}
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Total Violations
              </Typography>
              <Typography variant="h4">
                {stats.totalViolations.toLocaleString()}
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                {stats.recentTrend === 'down' ? (
                  <TrendingDownIcon color="success" />
                ) : (
                  <TrendingUpIcon color="error" />
                )}
                <Typography variant="body2" color={stats.recentTrend === 'down' ? 'success.main' : 'error.main'} sx={{ ml: 1 }}>
                  {stats.trendPercentage}% {stats.recentTrend === 'down' ? 'decrease' : 'increase'}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Open Violations
              </Typography>
              <Typography variant="h4">
                {stats.openViolations.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                {Math.round((stats.openViolations / stats.totalViolations) * 100)}% of total
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Resolved Violations
              </Typography>
              <Typography variant="h4">
                {stats.resolvedViolations.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                {Math.round((stats.resolvedViolations / stats.totalViolations) * 100)}% of total
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Critical Violations
              </Typography>
              <Typography variant="h4" color="error.main">
                {stats.criticalViolations.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="error.main" sx={{ mt: 1 }}>
                {Math.round((stats.criticalViolations / stats.totalViolations) * 100)}% of total
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Top Areas */}
        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardHeader title="Violations by Borough" />
            <Divider />
            <CardContent>
              <List>
                {stats.topAreas.map((area, index) => (
                  <ListItem key={index} divider={index < stats.topAreas.length - 1}>
                    <ListItemIcon>
                      <ApartmentIcon />
                    </ListItemIcon>
                    <ListItemText 
                      primary={area.name} 
                      secondary={`${area.count.toLocaleString()} violations (${area.percentage}%)`} 
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Violation Types */}
        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardHeader title="Top Violation Types" />
            <Divider />
            <CardContent>
              <List>
                {stats.violationTypes.map((violation, index) => (
                  <ListItem key={index} divider={index < stats.violationTypes.length - 1}>
                    <ListItemIcon>
                      {violation.severity === 'high' ? (
                        <WarningIcon color="error" />
                      ) : violation.severity === 'medium' ? (
                        <ReportProblemIcon color="warning" />
                      ) : (
                        <CheckCircleIcon color="success" />
                      )}
                    </ListItemIcon>
                    <ListItemText 
                      primary={violation.type} 
                      secondary={`${violation.count.toLocaleString()} violations`} 
                    />
                    <Chip 
                      label={violation.severity.toUpperCase()} 
                      color={
                        violation.severity === 'high' ? 'error' : 
                        violation.severity === 'medium' ? 'warning' : 'success'
                      }
                      size="small"
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        
        {/* AI Insights */}
        <Grid item xs={12}>
          <Card elevation={2}>
            <CardHeader 
              title="AI-Generated Insights" 
              subheader="Automatically generated based on data analysis"
            />
            <Divider />
            <CardContent>
              <List>
                {stats.recentInsights.map((insight, index) => (
                  <ListItem key={index} divider={index < stats.recentInsights.length - 1}>
                    <ListItemIcon>
                      <TrendingUpIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText primary={insight} />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
