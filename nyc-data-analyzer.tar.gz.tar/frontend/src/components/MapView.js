import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  Card, 
  CardContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Stack
} from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import WarningIcon from '@mui/icons-material/Warning';

// This would be replaced with an actual map library like Leaflet or Google Maps
const MapPlaceholder = ({ data }) => {
  const mapRef = useRef(null);
  
  useEffect(() => {
    // In a real implementation, this would initialize the map
    // and plot the data points
    if (mapRef.current) {
      const ctx = mapRef.current.getContext('2d');
      ctx.fillStyle = '#f0f0f0';
      ctx.fillRect(0, 0, mapRef.current.width, mapRef.current.height);
      
      // Draw NYC borough outlines (simplified)
      ctx.strokeStyle = '#cccccc';
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      // Manhattan (simplified rectangle)
      ctx.rect(150, 100, 100, 200);
      
      // Brooklyn (simplified shape)
      ctx.moveTo(250, 250);
      ctx.lineTo(350, 230);
      ctx.lineTo(380, 330);
      ctx.lineTo(280, 350);
      ctx.lineTo(250, 250);
      
      // Queens (simplified shape)
      ctx.moveTo(300, 150);
      ctx.lineTo(400, 130);
      ctx.lineTo(420, 230);
      ctx.lineTo(350, 230);
      ctx.lineTo(300, 150);
      
      // Bronx (simplified shape)
      ctx.moveTo(200, 50);
      ctx.lineTo(300, 30);
      ctx.lineTo(320, 100);
      ctx.lineTo(220, 120);
      ctx.lineTo(200, 50);
      
      // Staten Island (simplified shape)
      ctx.moveTo(100, 350);
      ctx.lineTo(150, 330);
      ctx.lineTo(170, 380);
      ctx.lineTo(120, 400);
      ctx.lineTo(100, 350);
      
      ctx.stroke();
      
      // Plot data points
      if (data && data.length > 0) {
        data.forEach(point => {
          ctx.fillStyle = point.severity === 'high' ? '#f44336' : 
                          point.severity === 'medium' ? '#ff9800' : '#4caf50';
          ctx.beginPath();
          ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
          ctx.fill();
        });
      }
      
      // Add NYC label
      ctx.fillStyle = '#000000';
      ctx.font = '16px Arial';
      ctx.fillText('New York City', 200, 20);
      
      // Add borough labels
      ctx.font = '12px Arial';
      ctx.fillText('Manhattan', 160, 200);
      ctx.fillText('Brooklyn', 300, 300);
      ctx.fillText('Queens', 350, 180);
      ctx.fillText('Bronx', 250, 80);
      ctx.fillText('Staten Island', 120, 370);
    }
  }, [data]);
  
  return (
    <canvas 
      ref={mapRef} 
      width={500} 
      height={450} 
      style={{ width: '100%', height: 'auto', maxWidth: '500px' }}
    />
  );
};

const MapView = () => {
  const [mapData, setMapData] = useState([]);
  const [dataType, setDataType] = useState('violations');
  const [severity, setSeverity] = useState('all');
  
  // Generate sample data for the map
  useEffect(() => {
    // In a real app, this would fetch data from the backend
    const generateSampleData = () => {
      const data = [];
      
      // Manhattan points
      for (let i = 0; i < 15; i++) {
        const severityOptions = ['low', 'medium', 'high'];
        const randomSeverity = severityOptions[Math.floor(Math.random() * severityOptions.length)];
        
        if (severity === 'all' || severity === randomSeverity) {
          data.push({
            id: `manhattan-${i}`,
            x: 150 + Math.random() * 100,
            y: 100 + Math.random() * 200,
            borough: 'Manhattan',
            address: `${100 + Math.floor(Math.random() * 100)} W ${10 + Math.floor(Math.random() * 90)}th St`,
            violations: 5 + Math.floor(Math.random() * 20),
            severity: randomSeverity
          });
        }
      }
      
      // Brooklyn points
      for (let i = 0; i < 20; i++) {
        const severityOptions = ['low', 'medium', 'high'];
        const randomSeverity = severityOptions[Math.floor(Math.random() * severityOptions.length)];
        
        if (severity === 'all' || severity === randomSeverity) {
          data.push({
            id: `brooklyn-${i}`,
            x: 250 + Math.random() * 100,
            y: 250 + Math.random() * 100,
            borough: 'Brooklyn',
            address: `${100 + Math.floor(Math.random() * 900)} ${['Bedford Ave', 'Atlantic Ave', 'Flatbush Ave'][Math.floor(Math.random() * 3)]}`,
            violations: 5 + Math.floor(Math.random() * 20),
            severity: randomSeverity
          });
        }
      }
      
      // Queens points
      for (let i = 0; i < 18; i++) {
        const severityOptions = ['low', 'medium', 'high'];
        const randomSeverity = severityOptions[Math.floor(Math.random() * severityOptions.length)];
        
        if (severity === 'all' || severity === randomSeverity) {
          data.push({
            id: `queens-${i}`,
            x: 300 + Math.random() * 100,
            y: 130 + Math.random() * 100,
            borough: 'Queens',
            address: `${100 + Math.floor(Math.random() * 900)} ${['Queens Blvd', 'Jamaica Ave', 'Northern Blvd'][Math.floor(Math.random() * 3)]}`,
            violations: 5 + Math.floor(Math.random() * 20),
            severity: randomSeverity
          });
        }
      }
      
      // Bronx points
      for (let i = 0; i < 12; i++) {
        const severityOptions = ['low', 'medium', 'high'];
        const randomSeverity = severityOptions[Math.floor(Math.random() * severityOptions.length)];
        
        if (severity === 'all' || severity === randomSeverity) {
          data.push({
            id: `bronx-${i}`,
            x: 200 + Math.random() * 100,
            y: 50 + Math.random() * 70,
            borough: 'Bronx',
            address: `${100 + Math.floor(Math.random() * 900)} ${['Grand Concourse', 'Fordham Rd', 'Jerome Ave'][Math.floor(Math.random() * 3)]}`,
            violations: 5 + Math.floor(Math.random() * 20),
            severity: randomSeverity
          });
        }
      }
      
      // Staten Island points
      for (let i = 0; i < 8; i++) {
        const severityOptions = ['low', 'medium', 'high'];
        const randomSeverity = severityOptions[Math.floor(Math.random() * severityOptions.length)];
        
        if (severity === 'all' || severity === randomSeverity) {
          data.push({
            id: `staten-${i}`,
            x: 100 + Math.random() * 70,
            y: 350 + Math.random() * 50,
            borough: 'Staten Island',
            address: `${100 + Math.floor(Math.random() * 900)} ${['Hylan Blvd', 'Richmond Ave', 'Victory Blvd'][Math.floor(Math.random() * 3)]}`,
            violations: 5 + Math.floor(Math.random() * 20),
            severity: randomSeverity
          });
        }
      }
      
      return data;
    };
    
    setMapData(generateSampleData());
  }, [dataType, severity]);
  
  // Count violations by borough
  const boroughCounts = mapData.reduce((acc, point) => {
    acc[point.borough] = (acc[point.borough] || 0) + 1;
    return acc;
  }, {});
  
  // Count by severity
  const severityCounts = mapData.reduce((acc, point) => {
    acc[point.severity] = (acc[point.severity] || 0) + 1;
    return acc;
  }, {});

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Map View
      </Typography>
      
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Geographic visualization of NYC housing data
      </Typography>
      
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 3 }}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel id="data-type-label">Data Type</InputLabel>
          <Select
            labelId="data-type-label"
            value={dataType}
            label="Data Type"
            onChange={(e) => setDataType(e.target.value)}
          >
            <MenuItem value="violations">Housing Violations</MenuItem>
            <MenuItem value="complaints">Housing Complaints</MenuItem>
            <MenuItem value="inspections">Building Inspections</MenuItem>
          </Select>
        </FormControl>
        
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel id="severity-label">Severity</InputLabel>
          <Select
            labelId="severity-label"
            value={severity}
            label="Severity"
            onChange={(e) => setSeverity(e.target.value)}
          >
            <MenuItem value="all">All Severities</MenuItem>
            <MenuItem value="low">Low</MenuItem>
            <MenuItem value="medium">Medium</MenuItem>
            <MenuItem value="high">High</MenuItem>
          </Select>
        </FormControl>
      </Box>
      
      <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3 }}>
        <Paper elevation={3} sx={{ flex: 2, p: 2, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <MapPlaceholder data={mapData} />
        </Paper>
        
        <Box sx={{ flex: 1 }}>
          <Card sx={{ mb: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Summary
              </Typography>
              <Typography variant="body2" gutterBottom>
                Total Points: {mapData.length}
              </Typography>
              <Typography variant="body2">
                Showing: {dataType === 'violations' ? 'Housing Violations' : 
                          dataType === 'complaints' ? 'Housing Complaints' : 'Building Inspections'}
              </Typography>
              
              <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>
                By Borough:
              </Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                {Object.entries(boroughCounts).map(([borough, count]) => (
                  <Chip 
                    key={borough}
                    icon={<LocationOnIcon />}
                    label={`${borough}: ${count}`}
                    variant="outlined"
                    size="small"
                    sx={{ mb: 1 }}
                  />
                ))}
              </Stack>
              
              <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>
                By Severity:
              </Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                {Object.entries(severityCounts).map(([sev, count]) => (
                  <Chip 
                    key={sev}
                    icon={<WarningIcon />}
                    label={`${sev.charAt(0).toUpperCase() + sev.slice(1)}: ${count}`}
                    color={sev === 'high' ? 'error' : sev === 'medium' ? 'warning' : 'success'}
                    size="small"
                    sx={{ mb: 1 }}
                  />
                ))}
              </Stack>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Legend
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#f44336', mr: 1 }} />
                <Typography variant="body2">High Severity</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#ff9800', mr: 1 }} />
                <Typography variant="body2">Medium Severity</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#4caf50', mr: 1 }} />
                <Typography variant="body2">Low Severity</Typography>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Box>
  );
};

export default MapView;
