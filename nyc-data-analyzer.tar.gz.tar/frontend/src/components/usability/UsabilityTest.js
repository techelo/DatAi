import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Stepper, 
  Step, 
  StepLabel, 
  Button, 
  TextField,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Rating,
  Divider,
  Alert
} from '@mui/material';

const tasks = [
  {
    id: 1,
    title: 'Connect to a data source',
    description: 'Try connecting to the test OData endpoint by entering "http://localhost:5000/api/test/odata" in the OData endpoint field and selecting OData V4.',
    expectedOutcome: 'The application should connect successfully and display a success message.'
  },
  {
    id: 2,
    title: 'View dashboard data',
    description: 'After connecting, navigate to the Dashboard view and explore the visualizations.',
    expectedOutcome: 'You should see charts and statistics about housing violations.'
  },
  {
    id: 3,
    title: 'Use the AI chat interface',
    description: 'Navigate to the AI Chat view and ask a question like "What are the most common housing violations in Brooklyn?"',
    expectedOutcome: 'The AI should respond with relevant information about housing violations in Brooklyn.'
  },
  {
    id: 4,
    title: 'Generate a report',
    description: 'Navigate to the Reports view and try generating a report with different settings.',
    expectedOutcome: 'You should be able to customize and preview a report with visualizations and insights.'
  },
  {
    id: 5,
    title: 'Explore the map view',
    description: 'Navigate to the Map View and explore the geographic distribution of violations.',
    expectedOutcome: 'You should see a map of NYC with data points representing violations.'
  }
];

const UsabilityTest = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [completed, setCompleted] = useState({});
  const [feedback, setFeedback] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleComplete = () => {
    const newCompleted = { ...completed };
    newCompleted[activeStep] = true;
    setCompleted(newCompleted);
    handleNext();
  };

  const handleFeedbackChange = (taskId, field, value) => {
    setFeedback({
      ...feedback,
      [taskId]: {
        ...(feedback[taskId] || {}),
        [field]: value
      }
    });
  };

  const handleSubmit = () => {
    // In a real application, this would send the feedback to a server
    console.log('Usability test feedback:', feedback);
    setSubmitted(true);
  };

  const isStepComplete = (step) => {
    return completed[step];
  };

  const renderTaskContent = (task) => {
    return (
      <Box sx={{ mt: 2 }}>
        <Typography variant="h6">{task.title}</Typography>
        <Typography variant="body1" sx={{ mt: 1 }}>{task.description}</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          <strong>Expected outcome:</strong> {task.expectedOutcome}
        </Typography>
        
        <Divider sx={{ my: 3 }} />
        
        <Typography variant="h6">Task Feedback</Typography>
        
        <FormControl component="fieldset" sx={{ mt: 2, width: '100%' }}>
          <FormLabel component="legend">Were you able to complete this task?</FormLabel>
          <RadioGroup
            row
            value={feedback[task.id]?.completed || ''}
            onChange={(e) => handleFeedbackChange(task.id, 'completed', e.target.value)}
          >
            <FormControlLabel value="yes" control={<Radio />} label="Yes" />
            <FormControlLabel value="partially" control={<Radio />} label="Partially" />
            <FormControlLabel value="no" control={<Radio />} label="No" />
          </RadioGroup>
        </FormControl>
        
        <Box sx={{ mt: 2 }}>
          <Typography component="legend">How easy was this task to complete?</Typography>
          <Rating
            name={`difficulty-${task.id}`}
            value={feedback[task.id]?.difficulty || 0}
            onChange={(event, newValue) => {
              handleFeedbackChange(task.id, 'difficulty', newValue);
            }}
          />
        </Box>
        
        <TextField
          fullWidth
          multiline
          rows={3}
          margin="normal"
          label="Additional comments about this task"
          value={feedback[task.id]?.comments || ''}
          onChange={(e) => handleFeedbackChange(task.id, 'comments', e.target.value)}
        />
      </Box>
    );
  };

  const renderSummary = () => {
    return (
      <Box sx={{ mt: 2 }}>
        <Typography variant="h6">Usability Test Summary</Typography>
        
        {submitted ? (
          <Alert severity="success" sx={{ mt: 2 }}>
            Thank you for completing the usability test! Your feedback has been recorded.
          </Alert>
        ) : (
          <>
            <Typography variant="body1" sx={{ mt: 1 }}>
              Please provide your overall feedback about the NYC Data Analyzer application.
            </Typography>
            
            <Box sx={{ mt: 2 }}>
              <Typography component="legend">Overall ease of use</Typography>
              <Rating
                name="overall-rating"
                value={feedback.overall?.rating || 0}
                onChange={(event, newValue) => {
                  handleFeedbackChange('overall', 'rating', newValue);
                }}
              />
            </Box>
            
            <TextField
              fullWidth
              multiline
              rows={4}
              margin="normal"
              label="What did you like most about the application?"
              value={feedback.overall?.liked || ''}
              onChange={(e) => handleFeedbackChange('overall', 'liked', e.target.value)}
            />
            
            <TextField
              fullWidth
              multiline
              rows={4}
              margin="normal"
              label="What aspects of the application could be improved?"
              value={feedback.overall?.improvements || ''}
              onChange={(e) => handleFeedbackChange('overall', 'improvements', e.target.value)}
            />
            
            <Button 
              variant="contained" 
              color="primary" 
              sx={{ mt: 2 }}
              onClick={handleSubmit}
            >
              Submit Feedback
            </Button>
          </>
        )}
      </Box>
    );
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Usability Testing
      </Typography>
      
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Help us improve the NYC Data Analyzer by completing these tasks and providing feedback
      </Typography>
      
      <Paper elevation={2} sx={{ p: 3 }}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {tasks.map((task, index) => (
            <Step key={task.id} completed={isStepComplete(index)}>
              <StepLabel>{task.title}</StepLabel>
            </Step>
          ))}
          <Step key="summary">
            <StepLabel>Summary</StepLabel>
          </Step>
        </Stepper>
        
        <Box sx={{ mt: 4 }}>
          {activeStep === tasks.length ? (
            renderSummary()
          ) : (
            renderTaskContent(tasks[activeStep])
          )}
        </Box>
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button
            variant="outlined"
            disabled={activeStep === 0}
            onClick={handleBack}
          >
            Back
          </Button>
          
          <Box>
            {activeStep < tasks.length ? (
              <Button
                variant="contained"
                color="primary"
                onClick={handleComplete}
              >
                {activeStep === tasks.length - 1 ? 'Finish' : 'Next'}
              </Button>
            ) : null}
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default UsabilityTest;
