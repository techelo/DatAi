import React, { useEffect, useRef } from 'react';
import { Box, Typography } from '@mui/material';
import Chart from 'chart.js/auto';

const MapChart = ({ title, data, mapLabels }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (chartRef.current) {
      // Destroy existing chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      const ctx = chartRef.current.getContext('2d');
      
      // Create a simplified map chart using a bubble chart
      chartInstance.current = new Chart(ctx, {
        type: 'bubble',
        data: {
          datasets: data.map((borough, index) => ({
            label: borough.name,
            data: borough.points.map(point => ({
              x: point.x,
              y: point.y,
              r: point.value / 10, // Scale the radius based on value
            })),
            backgroundColor: [
              'rgba(255, 99, 132, 0.6)',
              'rgba(54, 162, 235, 0.6)',
              'rgba(255, 206, 86, 0.6)',
              'rgba(75, 192, 192, 0.6)',
              'rgba(153, 102, 255, 0.6)',
            ][index % 5],
          })),
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              min: 0,
              max: 100,
              grid: {
                display: false,
              },
              ticks: {
                display: false,
              },
              title: {
                display: false,
              },
            },
            y: {
              min: 0,
              max: 100,
              grid: {
                display: false,
              },
              ticks: {
                display: false,
              },
              title: {
                display: false,
              },
            },
          },
          plugins: {
            legend: {
              position: 'bottom',
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const label = context.dataset.label || '';
                  const value = Math.round(context.raw.r * 10);
                  return `${label}: ${value} violations`;
                }
              }
            },
            annotation: {
              annotations: mapLabels.map(label => ({
                type: 'label',
                xValue: label.x,
                yValue: label.y,
                content: label.text,
                font: {
                  size: 12,
                },
                color: 'black',
              })),
            },
          },
        },
      });
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, mapLabels, title]);

  return (
    <Box sx={{ width: '100%', height: '400px', p: 2 }}>
      {title && (
        <Typography variant="h6" align="center" gutterBottom>
          {title}
        </Typography>
      )}
      <Box sx={{ position: 'relative', height: '100%', width: '100%' }}>
        <canvas ref={chartRef} />
      </Box>
    </Box>
  );
};

export default MapChart;
