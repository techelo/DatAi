import React, { useEffect, useRef } from 'react';
import { Box, Typography } from '@mui/material';
import Chart from 'chart.js/auto';

const LineChart = ({ title, data, labels, borderColor, backgroundColor, yAxisLabel, fill = false }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (chartRef.current) {
      // Destroy existing chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      const ctx = chartRef.current.getContext('2d');
      
      // Create new chart
      chartInstance.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: title,
              data: data,
              borderColor: borderColor || 'rgba(75, 192, 192, 1)',
              backgroundColor: backgroundColor || 'rgba(75, 192, 192, 0.2)',
              tension: 0.1,
              fill: fill,
              pointRadius: 3,
              pointHoverRadius: 5,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: !!yAxisLabel,
                text: yAxisLabel || '',
              },
            },
          },
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  return `${context.dataset.label}: ${context.parsed.y}`;
                }
              }
            }
          }
        },
      });
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, labels, title, borderColor, backgroundColor, yAxisLabel, fill]);

  return (
    <Box sx={{ width: '100%', height: '300px', p: 2 }}>
      {title && (
        <Typography variant="h6" align="center" gutterBottom>
          {title}
        </Typography>
      )}
      <Box sx={{ position: 'relative', height: '100%', width: '100%' }}>
        <canvas ref={chartRef} />
      </Box>
    </Box>
  );
};

export default LineChart;
