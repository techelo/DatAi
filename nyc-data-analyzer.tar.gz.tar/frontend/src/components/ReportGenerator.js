import React, { useState } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button,
  TextField,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Divider
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import BarChart from './visualizations/BarChart';
import PieChart from './visualizations/PieChart';
import LineChart from './visualizations/LineChart';

const ReportGenerator = ({ data }) => {
  const [reportTitle, setReportTitle] = useState('NYC Housing Violations Analysis');
  const [reportType, setReportType] = useState('comprehensive');
  const [timeRange, setTimeRange] = useState('all');
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includeInsights, setIncludeInsights] = useState(true);
  
  // Sample data for demonstration
  const sampleData = {
    boroughData: {
      labels: ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'],
      values: [2500, 3800, 4200, 1600, 400]
    },
    violationTypeData: {
      labels: ['Heat/Hot Water', 'Plumbing', 'Paint/Plaster', 'Electric', 'Pests'],
      values: [3200, 2800, 2300, 1900, 1500]
    },
    timeSeriesData: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      values: [1200, 1300, 1100, 900, 800, 750, 800, 850, 950, 1050, 1150, 1250]
    },
    insights: [
      'Heat/Hot Water violations increased by 15% in Queens during winter months',
      'Buildings in Brooklyn have shown a 22% decrease in electrical violations after recent inspections',
      'The Bronx has the highest concentration of critical violations per building',
      'Manhattan high-rises show consistent plumbing issues in buildings over 50 years old'
    ]
  };
  
  // Use provided data or fall back to sample data
  const reportData = data || sampleData;
  
  const handleGenerateReport = () => {
    // In a real implementation, this would generate a PDF or other report format
    console.log('Generating report with settings:', {
      reportTitle,
      reportType,
      timeRange,
      includeCharts,
      includeInsights
    });
    
    // For now, we'll just show an alert
    alert('Report generated! In a production environment, this would download a PDF or other report format.');
  };
  
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Report Generator
      </Typography>
      
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Generate custom reports from NYC housing data
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Report Settings
              </Typography>
              
              <Box sx={{ mb: 2 }}>
                <TextField
                  fullWidth
                  label="Report Title"
                  value={reportTitle}
                  onChange={(e) => setReportTitle(e.target.value)}
                  margin="normal"
                />
              </Box>
              
              <Box sx={{ mb: 2 }}>
                <FormControl fullWidth margin="normal">
                  <InputLabel>Report Type</InputLabel>
                  <Select
                    value={reportType}
                    label="Report Type"
                    onChange={(e) => setReportType(e.target.value)}
                  >
                    <MenuItem value="comprehensive">Comprehensive Analysis</MenuItem>
                    <MenuItem value="summary">Executive Summary</MenuItem>
                    <MenuItem value="violations">Violations Report</MenuItem>
                    <MenuItem value="trends">Trend Analysis</MenuItem>
                  </Select>
                </FormControl>
              </Box>
              
              <Box sx={{ mb: 2 }}>
                <FormControl fullWidth margin="normal">
                  <InputLabel>Time Range</InputLabel>
                  <Select
                    value={timeRange}
                    label="Time Range"
                    onChange={(e) => setTimeRange(e.target.value)}
                  >
                    <MenuItem value="all">All Time</MenuItem>
                    <MenuItem value="year">Past Year</MenuItem>
                    <MenuItem value="6months">Past 6 Months</MenuItem>
                    <MenuItem value="3months">Past 3 Months</MenuItem>
                    <MenuItem value="month">Past Month</MenuItem>
                  </Select>
                </FormControl>
              </Box>
              
              <Box sx={{ mb: 2 }}>
                <FormControl fullWidth margin="normal">
                  <InputLabel>Include Charts</InputLabel>
                  <Select
                    value={includeCharts ? 'yes' : 'no'}
                    label="Include Charts"
                    onChange={(e) => setIncludeCharts(e.target.value === 'yes')}
                  >
                    <MenuItem value="yes">Yes</MenuItem>
                    <MenuItem value="no">No</MenuItem>
                  </Select>
                </FormControl>
              </Box>
              
              <Box sx={{ mb: 2 }}>
                <FormControl fullWidth margin="normal">
                  <InputLabel>Include AI Insights</InputLabel>
                  <Select
                    value={includeInsights ? 'yes' : 'no'}
                    label="Include AI Insights"
                    onChange={(e) => setIncludeInsights(e.target.value === 'yes')}
                  >
                    <MenuItem value="yes">Yes</MenuItem>
                    <MenuItem value="no">No</MenuItem>
                  </Select>
                </FormControl>
              </Box>
              
              <Box sx={{ mt: 3 }}>
                <Button 
                  variant="contained" 
                  fullWidth
                  startIcon={<DownloadIcon />}
                  onClick={handleGenerateReport}
                >
                  Generate Report
                </Button>
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Typography variant="subtitle2" gutterBottom>
                Export Format
              </Typography>
              
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                <Button 
                  variant="outlined" 
                  size="small"
                  startIcon={<PictureAsPdfIcon />}
                >
                  PDF
                </Button>
                <Button 
                  variant="outlined" 
                  size="small"
                  startIcon={<TableChartIcon />}
                >
                  Excel
                </Button>
                <Button 
                  variant="outlined" 
                  size="small"
                >
                  CSV
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={8}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Report Preview
              </Typography>
              
              <Paper elevation={0} sx={{ p: 2, bgcolor: '#f5f5f5', mb: 3 }}>
                <Typography variant="h5" align="center" gutterBottom>
                  {reportTitle}
                </Typography>
                <Typography variant="subtitle2" align="center" color="text.secondary">
                  {timeRange === 'all' ? 'All Time Data' : 
                   timeRange === 'year' ? 'Past 12 Months' :
                   timeRange === '6months' ? 'Past 6 Months' :
                   timeRange === '3months' ? 'Past 3 Months' : 'Past Month'}
                </Typography>
              </Paper>
              
              {includeCharts && (
                <>
                  <Typography variant="subtitle1" gutterBottom>
                    Data Visualizations
                  </Typography>
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <BarChart 
                        title="Violations by Borough"
                        data={reportData.boroughData.values}
                        labels={reportData.boroughData.labels}
                        yAxisLabel="Number of Violations"
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <PieChart 
                        title="Violation Types Distribution"
                        data={reportData.violationTypeData.values}
                        labels={reportData.violationTypeData.labels}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <LineChart 
                        title="Violations Over Time"
                        data={reportData.timeSeriesData.values}
                        labels={reportData.timeSeriesData.labels}
                        yAxisLabel="Number of Violations"
                        fill={true}
                      />
                    </Grid>
                  </Grid>
                </>
              )}
              
              {includeInsights && (
                <>
                  <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                    AI-Generated Insights
                  </Typography>
                  
                  <Paper elevation={0} sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                    {reportData.insights.map((insight, index) => (
                      <Typography key={index} variant="body2" paragraph>
                        • {insight}
                      </Typography>
                    ))}
                  </Paper>
                </>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ReportGenerator;
