import React, { useState } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  TextField, 
  Button, 
  List, 
  ListItem, 
  ListItemText, 
  Chip,
  Avatar,
  IconButton
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import PersonIcon from '@mui/icons-material/Person';

const ChatInterface = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    { 
      id: 1, 
      text: 'Use natural language to analyze complex NYC housing datasets and get meaningful insights.', 
      sender: 'ai',
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  
  const [suggestions] = useState([
    'Which areas in Queens have the most HPD violations?',
    'Are there buildings in the Bronx with signs of illegal renovations?',
    'What are common violations in Manhattan high-rises?',
    'Show buildings with both DOB and HPD violations in 2023'
  ]);

  const handleSendMessage = () => {
    if (input.trim() === '') return;
    
    // Add user message
    const newUserMessage = {
      id: messages.length + 1,
      text: input,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString()
    };
    
    setMessages([...messages, newUserMessage]);
    setInput('');
    
    // Simulate AI response (in a real app, this would call the backend API)
    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        text: "I'm analyzing the NYC housing data based on your query. This might take a moment...",
        sender: 'ai',
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prevMessages => [...prevMessages, aiResponse]);
    }, 1000);
  };

  const handleSuggestionClick = (suggestion) => {
    setInput(suggestion);
  };

  return (
    <Paper elevation={3} sx={{ height: '100%', display: 'flex', flexDirection: 'column', p: 2, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        <SmartToyIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        AI-Powered Data Analysis
      </Typography>
      
      <Typography variant="body2" color="text.secondary" gutterBottom>
        Use natural language to analyze complex NYC housing datasets and get meaningful insights.
      </Typography>
      
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
        {suggestions.map((suggestion, index) => (
          <Chip 
            key={index} 
            label={suggestion} 
            variant="outlined" 
            onClick={() => handleSuggestionClick(suggestion)}
            sx={{ cursor: 'pointer' }}
          />
        ))}
      </Box>
      
      <Paper 
        variant="outlined" 
        sx={{ 
          flexGrow: 1, 
          mb: 2, 
          p: 2, 
          maxHeight: '300px', 
          overflowY: 'auto',
          bgcolor: 'background.default'
        }}
      >
        <List>
          {messages.map((message) => (
            <ListItem 
              key={message.id} 
              alignItems="flex-start"
              sx={{ 
                flexDirection: message.sender === 'user' ? 'row-reverse' : 'row',
                mb: 1
              }}
            >
              <Avatar 
                sx={{ 
                  bgcolor: message.sender === 'user' ? 'primary.main' : 'secondary.main',
                  ml: message.sender === 'user' ? 1 : 0,
                  mr: message.sender === 'user' ? 0 : 1
                }}
              >
                {message.sender === 'user' ? <PersonIcon /> : <SmartToyIcon />}
              </Avatar>
              <Paper 
                elevation={0} 
                sx={{ 
                  p: 1.5, 
                  borderRadius: 2,
                  maxWidth: '80%',
                  bgcolor: message.sender === 'user' ? 'primary.light' : 'grey.100',
                  color: message.sender === 'user' ? 'white' : 'text.primary'
                }}
              >
                <ListItemText 
                  primary={message.text} 
                  secondary={message.timestamp}
                  secondaryTypographyProps={{
                    color: message.sender === 'user' ? 'white' : 'text.secondary',
                    fontSize: '0.7rem'
                  }}
                />
              </Paper>
            </ListItem>
          ))}
        </List>
      </Paper>
      
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Ask a question about NYC housing data..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          size="small"
          sx={{ mr: 1 }}
        />
        <Button 
          variant="contained" 
          color="primary" 
          endIcon={<SendIcon />}
          onClick={handleSendMessage}
        >
          Analyze
        </Button>
      </Box>
    </Paper>
  );
};

export default ChatInterface;
