import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Box, Container, Typography, CircularProgress, Alert } from '@mui/material';
import ODataConnector from './ODataConnector';
import ChatInterface from './ChatInterface';
import Dashboard from './Dashboard';
import MapView from './MapView';
import ReportGenerator from './ReportGenerator';

const DatasetAnalyzer = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [connected, setConnected] = useState(false);
  const [odataEndpoint, setOdataEndpoint] = useState('');
  const [odataVersion, setOdataVersion] = useState('v4');
  const [data, setData] = useState(null);
  const [insights, setInsights] = useState([]);
  const [activeView, setActiveView] = useState('dashboard');

  // Connect to OData endpoint
  const handleConnect = async (endpoint, version) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.get('/api/odata/test', {
        params: { endpoint, version }
      });
      
      if (response.data.success) {
        setConnected(true);
        setOdataEndpoint(endpoint);
        setOdataVersion(version);
        
        // Fetch initial data
        await fetchData(endpoint, version);
      } else {
        setError('Failed to connect to OData endpoint');
        setConnected(false);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Error connecting to OData endpoint');
      setConnected(false);
    } finally {
      setLoading(false);
    }
  };

  // Fetch data from OData endpoint
  const fetchData = async (endpoint, version, query = '') => {
    setLoading(true);
    
    try {
      const response = await axios.get('/api/odata/query', {
        params: { endpoint, version, query }
      });
      
      if (response.data.success) {
        setData(response.data.data);
        
        // Generate insights from data
        await generateInsights(response.data.data);
      } else {
        setError('Failed to fetch data from OData endpoint');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Error fetching data');
    } finally {
      setLoading(false);
    }
  };

  // Generate insights from data using AI
  const generateInsights = async (data) => {
    try {
      const response = await axios.post('/api/ai/analyze', {
        endpoint: odataEndpoint,
        version: odataVersion,
        question: 'Generate key insights from this data'
      });
      
      if (response.data.success) {
        // Parse insights from AI response
        const insightText = response.data.analysis.text;
        const parsedInsights = insightText
          .split('\n')
          .filter(line => line.trim().length > 0)
          .map(line => line.replace(/^\d+\.\s*/, '').trim())
          .filter(line => line.length > 20)
          .slice(0, 5);
        
        setInsights(parsedInsights.length > 0 ? parsedInsights : [
          'Insufficient data to generate meaningful insights',
          'Try querying a larger dataset or providing more specific context'
        ]);
      }
    } catch (err) {
      console.error('Error generating insights:', err);
      setInsights([
        'Error generating AI insights',
        'Housing violations data requires careful analysis to identify patterns',
        'Consider exploring correlations between violation types and building characteristics'
      ]);
    }
  };

  // Handle chat messages
  const handleChatMessage = async (message) => {
    try {
      const response = await axios.post('/api/ai/chat', {
        messages: [{ sender: 'user', text: message }],
        odataEndpoint
      });
      
      return response.data.response.text;
    } catch (err) {
      console.error('Error processing chat message:', err);
      return "I'm sorry, I encountered an error while processing your request. Please try again.";
    }
  };

  // Render the active view
  const renderActiveView = () => {
    if (!connected) {
      return (
        <Box sx={{ p: 3 }}>
          <Typography variant="h5" gutterBottom>
            Connect to OData Endpoint
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Enter an OData endpoint to start analyzing data
          </Typography>
          <ODataConnector onConnect={handleConnect} />
        </Box>
      );
    }

    switch (activeView) {
      case 'dashboard':
        return <Dashboard data={data} insights={insights} />;
      case 'map':
        return <MapView data={data} />;
      case 'chat':
        return (
          <Box sx={{ p: 3, height: '80vh' }}>
            <ChatInterface onSendMessage={handleChatMessage} />
          </Box>
        );
      case 'report':
        return <ReportGenerator data={data} />;
      default:
        return <Dashboard data={data} insights={insights} />;
    }
  };

  return (
    <Container maxWidth="xl">
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      )}
      
      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}
      
      {connected && (
        <Box sx={{ mb: 2, mt: 2 }}>
          <Alert severity="success">
            Connected to: {odataEndpoint} (OData {odataVersion})
          </Alert>
          <Box sx={{ display: 'flex', mt: 2, mb: 2 }}>
            <Box 
              onClick={() => setActiveView('dashboard')}
              sx={{ 
                p: 1, 
                mr: 1, 
                cursor: 'pointer',
                bgcolor: activeView === 'dashboard' ? 'primary.main' : 'grey.200',
                color: activeView === 'dashboard' ? 'white' : 'text.primary',
                borderRadius: 1
              }}
            >
              Dashboard
            </Box>
            <Box 
              onClick={() => setActiveView('map')}
              sx={{ 
                p: 1, 
                mr: 1, 
                cursor: 'pointer',
                bgcolor: activeView === 'map' ? 'primary.main' : 'grey.200',
                color: activeView === 'map' ? 'white' : 'text.primary',
                borderRadius: 1
              }}
            >
              Map View
            </Box>
            <Box 
              onClick={() => setActiveView('chat')}
              sx={{ 
                p: 1, 
                mr: 1, 
                cursor: 'pointer',
                bgcolor: activeView === 'chat' ? 'primary.main' : 'grey.200',
                color: activeView === 'chat' ? 'white' : 'text.primary',
                borderRadius: 1
              }}
            >
              AI Chat
            </Box>
            <Box 
              onClick={() => setActiveView('report')}
              sx={{ 
                p: 1, 
                cursor: 'pointer',
                bgcolor: activeView === 'report' ? 'primary.main' : 'grey.200',
                color: activeView === 'report' ? 'white' : 'text.primary',
                borderRadius: 1
              }}
            >
              Reports
            </Box>
          </Box>
        </Box>
      )}
      
      {renderActiveView()}
    </Container>
  );
};

export default DatasetAnalyzer;
