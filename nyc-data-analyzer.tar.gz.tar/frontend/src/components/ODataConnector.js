import React, { useState } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  TextField, 
  MenuItem, 
  Select, 
  FormControl, 
  InputLabel,
  Button,
  Grid,
  Divider
} from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import RefreshIcon from '@mui/icons-material/Refresh';

const ODataConnector = () => {
  const [endpoint, setEndpoint] = useState('');
  const [version, setVersion] = useState('v4');
  const [status, setStatus] = useState('disconnected');
  
  const handleConnect = () => {
    if (!endpoint) return;
    
    // In a real app, this would validate and connect to the OData endpoint
    setStatus('connecting');
    
    // Simulate connection delay
    setTimeout(() => {
      setStatus('connected');
    }, 1500);
  };
  
  const handleRefresh = () => {
    if (status !== 'connected') return;
    
    setStatus('refreshing');
    
    // Simulate refresh delay
    setTimeout(() => {
      setStatus('connected');
    }, 1000);
  };
  
  return (
    <Paper elevation={3} sx={{ p: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        OData Connection
      </Typography>
      
      <Typography variant="body2" color="text.secondary" gutterBottom>
        Connect to an OData endpoint to analyze data. The primary use is for datasets from NYC OpenData.
      </Typography>
      
      <Box sx={{ mt: 3 }}>
        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="OData Endpoint URL"
              variant="outlined"
              placeholder="https://data.cityofnewyork.us/resource/wvxf-dwi5"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
              helperText="Enter the full URL of the OData endpoint"
            />
          </Grid>
          
          <Grid item xs={6} md={3}>
            <FormControl fullWidth>
              <InputLabel id="odata-version-label">OData Version</InputLabel>
              <Select
                labelId="odata-version-label"
                value={version}
                label="OData Version"
                onChange={(e) => setVersion(e.target.value)}
              >
                <MenuItem value="v2">OData V2</MenuItem>
                <MenuItem value="v4">OData V4</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={6} md={3}>
            <Button
              variant="contained"
              color="primary"
              fullWidth
              startIcon={status === 'connected' ? <RefreshIcon /> : <CloudUploadIcon />}
              onClick={status === 'connected' ? handleRefresh : handleConnect}
              disabled={!endpoint || status === 'connecting' || status === 'refreshing'}
            >
              {status === 'connected' ? 'Refresh Data' : 
               status === 'connecting' ? 'Connecting...' : 
               status === 'refreshing' ? 'Refreshing...' : 'Connect'}
            </Button>
          </Grid>
        </Grid>
      </Box>
      
      <Divider sx={{ my: 3 }} />
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="body2" color="text.secondary">
          Connection Status: 
          <span style={{ 
            color: status === 'connected' ? 'green' : 
                  status === 'connecting' || status === 'refreshing' ? 'orange' : 'red',
            fontWeight: 'bold',
            marginLeft: '8px'
          }}>
            {status === 'connected' ? 'Connected' : 
             status === 'connecting' ? 'Connecting...' : 
             status === 'refreshing' ? 'Refreshing...' : 'Disconnected'}
          </span>
        </Typography>
        
        {status === 'connected' && (
          <Typography variant="body2" color="text.secondary">
            Last Updated: {new Date().toLocaleString()}
          </Typography>
        )}
      </Box>
      
      {status === 'connected' && (
        <Box sx={{ mt: 2, p: 2, bgcolor: 'success.light', borderRadius: 1 }}>
          <Typography variant="body2" color="success.contrastText">
            Successfully connected to OData endpoint. You can now use the AI chat interface to analyze this data.
          </Typography>
        </Box>
      )}
    </Paper>
  );
};

export default ODataConnector;
