import React, { useState } from 'react';
import { Box, Container, CssBaseline, ThemeProvider, createTheme, Tabs, Tab } from '@mui/material';
import Navbar from './components/Navbar';
import DatasetAnalyzer from './components/DatasetAnalyzer';
import TestHarness from './components/TestHarness';
import UsabilityTest from './components/usability/UsabilityTest';

// Create a theme instance
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
  },
});

function App() {
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <Navbar />
        <Container maxWidth="xl" sx={{ flexGrow: 1, py: 3 }}>
          <Tabs value={activeTab} onChange={handleTabChange} sx={{ mb: 3 }}>
            <Tab label="NYC Data Analyzer" />
            <Tab label="Test Harness" />
            <Tab label="Usability Testing" />
          </Tabs>
          
          {activeTab === 0 ? (
            <DatasetAnalyzer />
          ) : activeTab === 1 ? (
            <TestHarness />
          ) : (
            <UsabilityTest />
          )}
        </Container>
      </Box>
    </ThemeProvider>
  );
}

export default App;
