# NYC Data Analyzer

A web application that uses generative AI to analyze datasets using OData, providing a direct connection to data that can be refreshed on-demand within the connected application.

## Features

- **OData Integration**: Connect to any OData endpoint (V2 or V4) to analyze data
- **AI-Powered Analysis**: Use natural language to query and analyze datasets
- **Interactive Dashboard**: Visualize data with charts, graphs, and statistics
- **Map View**: Geographic visualization of data points
- **Report Generation**: Create custom reports with AI-generated insights
- **Chat Interface**: Interact with AI to make requests on the desired data

## Primary Use Case

The primary use case is to analyze datasets available on [NYC OpenData](https://opendata.cityofnewyork.us/), particularly focusing on housing-related datasets such as:

- Housing Maintenance Code Violations
- DOB Violations
- PLUTO (Property Land Use Tax Lot Output) data

## Technologies Used

- **Frontend**: React, Material-UI, Chart.js
- **Backend**: Node.js, Express
- **AI Integration**: Hugging Face API
- **Data Protocol**: OData (V2 and V4 support)

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/nyc-data-analyzer.git
cd nyc-data-analyzer
```

2. Install dependencies
```bash
npm install
```

3. Create a `.env` file in the root directory with the following variables:
```
PORT=5000
NODE_ENV=development
HUGGING_FACE_API_KEY=your_hugging_face_api_key
```

4. Start the development server
```bash
npm run dev
```

This will start both the frontend and backend servers concurrently.

## Usage

### Connecting to an OData Endpoint

1. Navigate to the main application
2. Enter the OData endpoint URL in the input field
3. Select the OData version (V2 or V4)
4. Click "Connect"

### Analyzing Data with AI

1. After connecting to an OData endpoint, navigate to the "AI Chat" tab
2. Enter your question or request in natural language
3. The AI will analyze the data and provide insights

### Generating Reports

1. Navigate to the "Reports" tab
2. Configure your report settings (title, type, time range, etc.)
3. Preview the report with charts and insights
4. Export the report in your preferred format (PDF, Excel, CSV)

## Testing

The application includes a comprehensive testing infrastructure:

1. Navigate to the "Test Harness" tab to run systematic tests
2. Use the "Usability Testing" tab to perform guided usability tests

## Browser Compatibility

The application is designed to work on modern browsers including:
- Chrome (v70+)
- Firefox (v60+)
- Safari (v12+)
- Edge (v80+)

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- NYC OpenData for providing the datasets
- Hugging Face for the AI capabilities
- OData protocol for standardized data access
