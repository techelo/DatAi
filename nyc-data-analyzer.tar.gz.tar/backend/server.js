const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Import routes
const odataRoutes = require('./routes/odata');
const aiRoutes = require('./routes/ai');
const testRoutes = require('./routes/test');

// Use routes
app.use('/api/odata', odataRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/test', testRoutes);

// Basic route
app.get('/api', (req, res) => {
  res.json({ message: 'Welcome to NYC Data Analyzer API' });
});

// Serve static assets in production
if (process.env.NODE_ENV === 'production') {
  // Set static folder
  app.use(express.static(path.join(__dirname, '../frontend/build')));

  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, '../frontend/build', 'index.html'));
  });
}

// Define port
const PORT = process.env.PORT || 5000;

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
