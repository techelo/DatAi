const express = require('express');
const router = express.Router();
const axios = require('axios');
const config = require('../config/default');

/**
 * @route   POST /api/ai/chat
 * @desc    Process chat messages with Hugging Face AI
 * @access  Public
 */
router.post('/chat', async (req, res) => {
  try {
    const { messages, odataEndpoint } = req.body;
    
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ success: false, message: 'Messages are required' });
    }
    
    // Get the latest user message
    const userMessage = messages[messages.length - 1];
    
    // Check if we have an API key
    const apiKey = process.env.HUGGING_FACE_API_KEY || '';
    if (!apiKey) {
      console.warn('No Hugging Face API key provided. Using fallback responses.');
      return res.json({
        success: true,
        response: {
          text: "I'm sorry, but I can't process your request right now as the AI service is not configured. Please add a Hugging Face API key to enable AI analysis.",
          type: 'text'
        }
      });
    }
    
    try {
      // Prepare the prompt with context about NYC housing data
      const prompt = {
        messages: [
          {
            role: "system",
            content: `You are an AI assistant specialized in analyzing NYC housing data. 
                     ${odataEndpoint ? `You have access to data from: ${odataEndpoint}` : 
                     'You can analyze NYC housing violations, building complaints, and other housing-related datasets.'}
                     Provide clear, concise analyses and insights based on the data.`
          },
          ...messages.map(msg => ({
            role: msg.sender === 'user' ? 'user' : 'assistant',
            content: msg.text
          }))
        ]
      };
      
      // Call Hugging Face API
      const response = await axios.post(
        `${config.huggingFace.baseUrl}/${config.huggingFace.defaultModel}`,
        prompt,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000 // 30 seconds timeout
        }
      );
      
      // Extract the AI response
      const aiResponse = response.data.generated_text || 
                         "I'm sorry, I couldn't generate a response. Please try again.";
      
      return res.json({
        success: true,
        response: {
          text: aiResponse,
          type: 'text'
        }
      });
    } catch (error) {
      console.error('AI processing error:', error.message);
      
      // Provide a fallback response
      return res.json({
        success: true,
        response: {
          text: "I'm sorry, I encountered an error while processing your request. Please try again or rephrase your question.",
          type: 'text',
          error: error.message
        }
      });
    }
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

/**
 * @route   POST /api/ai/analyze
 * @desc    Analyze data from OData endpoint
 * @access  Public
 */
router.post('/analyze', async (req, res) => {
  try {
    const { endpoint, version, query, question } = req.body;
    
    if (!endpoint) {
      return res.status(400).json({ success: false, message: 'OData endpoint is required' });
    }
    
    if (!question) {
      return res.status(400).json({ success: false, message: 'Analysis question is required' });
    }
    
    // Validate endpoint URL
    try {
      new URL(endpoint);
    } catch (error) {
      return res.status(400).json({ success: false, message: 'Invalid OData endpoint URL' });
    }
    
    // First, fetch data from the OData endpoint
    const queryUrl = query ? `${endpoint}?${query}` : endpoint;
    let data;
    
    try {
      const response = await axios.get(queryUrl, {
        headers: {
          Accept: version === 'v2' ? 'application/json' : 'application/json;odata.metadata=minimal'
        },
        timeout: 30000
      });
      
      data = response.data;
    } catch (error) {
      console.error('OData query error:', error.message);
      return res.status(500).json({
        success: false,
        message: 'Failed to query OData endpoint',
        error: error.message
      });
    }
    
    // Check if we have an API key
    const apiKey = process.env.HUGGING_FACE_API_KEY || '';
    if (!apiKey) {
      console.warn('No Hugging Face API key provided. Using fallback responses.');
      return res.json({
        success: true,
        analysis: {
          text: "I'm sorry, but I can't analyze this data right now as the AI service is not configured. Please add a Hugging Face API key to enable AI analysis.",
          type: 'text'
        }
      });
    }
    
    try {
      // Prepare a sample of the data for the AI to analyze
      const dataSample = Array.isArray(data.value) ? 
        data.value.slice(0, 10) : // Take first 10 items if it's an array
        data; // Otherwise use the whole response
      
      // Prepare the prompt for data analysis
      const prompt = {
        messages: [
          {
            role: "system",
            content: `You are an AI data analyst specialized in NYC housing data. 
                     Analyze the following data sample and answer the user's question.
                     Provide clear, concise insights based on the data.
                     Data sample: ${JSON.stringify(dataSample)}`
          },
          {
            role: "user",
            content: question
          }
        ]
      };
      
      // Call Hugging Face API
      const response = await axios.post(
        `${config.huggingFace.baseUrl}/${config.huggingFace.defaultModel}`,
        prompt,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );
      
      // Extract the AI analysis
      const aiAnalysis = response.data.generated_text || 
                         "I'm sorry, I couldn't generate an analysis. Please try again.";
      
      return res.json({
        success: true,
        analysis: {
          text: aiAnalysis,
          type: 'text',
          dataCount: Array.isArray(data.value) ? data.value.length : 1
        }
      });
    } catch (error) {
      console.error('AI analysis error:', error.message);
      
      // Provide a fallback response
      return res.json({
        success: true,
        analysis: {
          text: "I'm sorry, I encountered an error while analyzing the data. Please try again or rephrase your question.",
          type: 'text',
          error: error.message
        }
      });
    }
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

module.exports = router;
