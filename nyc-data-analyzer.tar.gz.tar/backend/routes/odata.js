const express = require('express');
const router = express.Router();
const axios = require('axios');
const config = require('../config/default');

/**
 * @route   GET /api/odata/test
 * @desc    Test OData endpoint connection
 * @access  Public
 */
router.get('/test', async (req, res) => {
  try {
    const { endpoint, version } = req.query;
    
    if (!endpoint) {
      return res.status(400).json({ success: false, message: 'OData endpoint is required' });
    }
    
    // Validate endpoint URL
    try {
      new URL(endpoint);
    } catch (error) {
      return res.status(400).json({ success: false, message: 'Invalid OData endpoint URL' });
    }
    
    // Attempt to connect to the endpoint
    try {
      const response = await axios.get(endpoint, {
        headers: {
          Accept: version === 'v2' ? 'application/json' : 'application/json;odata.metadata=minimal'
        },
        timeout: 10000 // 10 seconds timeout
      });
      
      return res.json({
        success: true,
        message: 'Successfully connected to OData endpoint',
        metadata: response.data
      });
    } catch (error) {
      console.error('OData connection error:', error.message);
      return res.status(500).json({
        success: false,
        message: 'Failed to connect to OData endpoint',
        error: error.message
      });
    }
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

/**
 * @route   GET /api/odata/query
 * @desc    Query OData endpoint
 * @access  Public
 */
router.get('/query', async (req, res) => {
  try {
    const { endpoint, version, query } = req.query;
    
    if (!endpoint) {
      return res.status(400).json({ success: false, message: 'OData endpoint is required' });
    }
    
    // Validate endpoint URL
    try {
      new URL(endpoint);
    } catch (error) {
      return res.status(400).json({ success: false, message: 'Invalid OData endpoint URL' });
    }
    
    // Construct the query URL
    const queryUrl = query ? `${endpoint}?${query}` : endpoint;
    
    // Execute the query
    try {
      const response = await axios.get(queryUrl, {
        headers: {
          Accept: version === 'v2' ? 'application/json' : 'application/json;odata.metadata=minimal'
        },
        timeout: 30000 // 30 seconds timeout for potentially large queries
      });
      
      return res.json({
        success: true,
        data: response.data
      });
    } catch (error) {
      console.error('OData query error:', error.message);
      return res.status(500).json({
        success: false,
        message: 'Failed to query OData endpoint',
        error: error.message
      });
    }
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

/**
 * @route   GET /api/odata/nyc/datasets
 * @desc    Get list of NYC OpenData datasets
 * @access  Public
 */
router.get('/nyc/datasets', async (req, res) => {
  try {
    // NYC OpenData API endpoint for datasets
    const nycDatasetUrl = 'https://data.cityofnewyork.us/api/catalog/v1';
    
    try {
      const response = await axios.get(nycDatasetUrl, {
        params: {
          domains: 'housing-development',
          limit: 100
        },
        timeout: 10000
      });
      
      // Extract relevant dataset information
      const datasets = response.data.results.map(dataset => ({
        id: dataset.resource.id,
        name: dataset.resource.name,
        description: dataset.resource.description,
        category: dataset.classification.domain_category,
        updatedAt: dataset.resource.updatedAt,
        permalink: dataset.permalink
      }));
      
      return res.json({
        success: true,
        count: datasets.length,
        datasets
      });
    } catch (error) {
      console.error('NYC OpenData API error:', error.message);
      return res.status(500).json({
        success: false,
        message: 'Failed to fetch NYC OpenData datasets',
        error: error.message
      });
    }
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

module.exports = router;
