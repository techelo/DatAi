const express = require('express');
const router = express.Router();
const testData = require('../testData');

/**
 * @route   GET /api/test/data
 * @desc    Get test data for the application
 * @access  Public
 */
router.get('/data', (req, res) => {
  try {
    const { dataset } = req.query;
    
    if (!dataset || !testData[dataset]) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid dataset specified. Available options: housingViolations, dobViolations, plutoData' 
      });
    }
    
    return res.json({
      success: true,
      data: testData[dataset]
    });
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

/**
 * @route   GET /api/test/odata
 * @desc    Test OData endpoint with sample data
 * @access  Public
 */
router.get('/odata', (req, res) => {
  try {
    const { dataset } = req.query;
    
    if (!dataset || !testData[dataset]) {
      return res.json({
        success: true,
        message: 'Successfully connected to test OData endpoint',
        metadata: {
          "@odata.context": "https://test-odata-endpoint/$metadata",
          "value": [
            {
              "name": "housingViolations",
              "kind": "EntitySet",
              "url": "housingViolations"
            },
            {
              "name": "dobViolations",
              "kind": "EntitySet",
              "url": "dobViolations"
            },
            {
              "name": "plutoData",
              "kind": "EntitySet",
              "url": "plutoData"
            }
          ]
        }
      });
    }
    
    return res.json({
      success: true,
      message: 'Successfully connected to test OData endpoint',
      metadata: {
        "@odata.context": `https://test-odata-endpoint/$metadata#${dataset}`,
        "value": testData[dataset].value.slice(0, 2) // Return just a sample
      }
    });
  } catch (error) {
    console.error('Server error:', error.message);
    return res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
});

module.exports = router;
