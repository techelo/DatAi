module.exports = {
  // Server configuration
  port: process.env.PORT || 5000,
  
  // Hugging Face API configuration
  huggingFace: {
    apiKey: process.env.HUGGING_FACE_API_KEY || '',
    baseUrl: 'https://api-inference.huggingface.co/models',
    defaultModel: 'google/gemma-2-2b-it'
  },
  
  // OData configuration
  odata: {
    defaultVersion: 'v4'
  },
  
  // NYC OpenData configuration
  nycOpenData: {
    baseUrl: 'https://data.cityofnewyork.us/resource',
    defaultDatasets: {
      housingViolations: 'wvxf-dwi5',
      buildingViolations: 'bivs-9x99'
    }
  }
};
