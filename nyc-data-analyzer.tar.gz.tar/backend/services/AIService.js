const axios = require('axios');
const config = require('../config/default');

/**
 * Utility functions for AI operations
 */
class AIService {
  /**
   * Process chat messages with Hugging Face AI
   * @param {Array} messages - Array of chat messages
   * @param {string} odataEndpoint - Optional OData endpoint for context
   * @returns {Promise} - AI response
   */
  static async processChat(messages, odataEndpoint) {
    try {
      // Check if we have an API key
      const apiKey = process.env.HUGGING_FACE_API_KEY || '';
      if (!apiKey) {
        console.warn('No Hugging Face API key provided. Using fallback responses.');
        return {
          success: true,
          response: {
            text: "I'm sorry, but I can't process your request right now as the AI service is not configured. Please add a Hugging Face API key to enable AI analysis.",
            type: 'text'
          }
        };
      }
      
      // Prepare the prompt with context about NYC housing data
      const prompt = {
        messages: [
          {
            role: "system",
            content: `You are an AI assistant specialized in analyzing NYC housing data. 
                     ${odataEndpoint ? `You have access to data from: ${odataEndpoint}` : 
                     'You can analyze NYC housing violations, building complaints, and other housing-related datasets.'}
                     Provide clear, concise analyses and insights based on the data.`
          },
          ...messages.map(msg => ({
            role: msg.sender === 'user' ? 'user' : 'assistant',
            content: msg.text
          }))
        ]
      };
      
      // Call Hugging Face API
      const response = await axios.post(
        `${config.huggingFace.baseUrl}/${config.huggingFace.defaultModel}`,
        prompt,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000 // 30 seconds timeout
        }
      );
      
      // Extract the AI response
      const aiResponse = response.data.generated_text || 
                         "I'm sorry, I couldn't generate a response. Please try again.";
      
      return {
        success: true,
        response: {
          text: aiResponse,
          type: 'text'
        }
      };
    } catch (error) {
      console.error('AI processing error:', error.message);
      
      // Provide a fallback response
      return {
        success: true,
        response: {
          text: "I'm sorry, I encountered an error while processing your request. Please try again or rephrase your question.",
          type: 'text',
          error: error.message
        }
      };
    }
  }
  
  /**
   * Analyze data from OData endpoint
   * @param {Object} data - Data from OData endpoint
   * @param {string} question - User's analysis question
   * @returns {Promise} - AI analysis
   */
  static async analyzeData(data, question) {
    try {
      // Check if we have an API key
      const apiKey = process.env.HUGGING_FACE_API_KEY || '';
      if (!apiKey) {
        console.warn('No Hugging Face API key provided. Using fallback responses.');
        return {
          success: true,
          analysis: {
            text: "I'm sorry, but I can't analyze this data right now as the AI service is not configured. Please add a Hugging Face API key to enable AI analysis.",
            type: 'text'
          }
        };
      }
      
      // Prepare a sample of the data for the AI to analyze
      const dataSample = Array.isArray(data.value) ? 
        data.value.slice(0, 10) : // Take first 10 items if it's an array
        data; // Otherwise use the whole response
      
      // Prepare the prompt for data analysis
      const prompt = {
        messages: [
          {
            role: "system",
            content: `You are an AI data analyst specialized in NYC housing data. 
                     Analyze the following data sample and answer the user's question.
                     Provide clear, concise insights based on the data.
                     Data sample: ${JSON.stringify(dataSample)}`
          },
          {
            role: "user",
            content: question
          }
        ]
      };
      
      // Call Hugging Face API
      const response = await axios.post(
        `${config.huggingFace.baseUrl}/${config.huggingFace.defaultModel}`,
        prompt,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );
      
      // Extract the AI analysis
      const aiAnalysis = response.data.generated_text || 
                         "I'm sorry, I couldn't generate an analysis. Please try again.";
      
      return {
        success: true,
        analysis: {
          text: aiAnalysis,
          type: 'text',
          dataCount: Array.isArray(data.value) ? data.value.length : 1
        }
      };
    } catch (error) {
      console.error('AI analysis error:', error.message);
      
      // Provide a fallback response
      return {
        success: true,
        analysis: {
          text: "I'm sorry, I encountered an error while analyzing the data. Please try again or rephrase your question.",
          type: 'text',
          error: error.message
        }
      };
    }
  }
  
  /**
   * Generate insights from data
   * @param {Object} data - Data from OData endpoint
   * @returns {Promise} - AI-generated insights
   */
  static async generateInsights(data) {
    try {
      // Check if we have an API key
      const apiKey = process.env.HUGGING_FACE_API_KEY || '';
      if (!apiKey) {
        console.warn('No Hugging Face API key provided. Using fallback insights.');
        return {
          success: true,
          insights: [
            "Configure Hugging Face API key to enable AI-generated insights",
            "Sample insight: Housing violations tend to be concentrated in specific neighborhoods",
            "Sample insight: Seasonal patterns may affect certain types of violations",
            "Sample insight: Building age correlates with violation frequency"
          ]
        };
      }
      
      // Prepare a sample of the data for the AI to analyze
      const dataSample = Array.isArray(data.value) ? 
        data.value.slice(0, 20) : // Take first 20 items if it's an array
        data; // Otherwise use the whole response
      
      // Prepare the prompt for generating insights
      const prompt = {
        messages: [
          {
            role: "system",
            content: `You are an AI data analyst specialized in NYC housing data. 
                     Generate 4-5 key insights from the following data sample.
                     Each insight should be a single sentence highlighting a pattern, trend, or notable observation.
                     Focus on actionable insights that would be valuable for housing policy or enforcement.
                     Data sample: ${JSON.stringify(dataSample)}`
          },
          {
            role: "user",
            content: "Generate key insights from this NYC housing data."
          }
        ]
      };
      
      // Call Hugging Face API
      const response = await axios.post(
        `${config.huggingFace.baseUrl}/${config.huggingFace.defaultModel}`,
        prompt,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );
      
      // Extract and parse the AI-generated insights
      const aiResponse = response.data.generated_text || "";
      
      // Split the response into individual insights
      const insights = aiResponse
        .split('\n')
        .filter(line => line.trim().length > 0)
        .map(line => line.replace(/^\d+\.\s*/, '').trim()) // Remove numbering if present
        .filter(line => line.length > 20) // Filter out too short lines
        .slice(0, 5); // Take at most 5 insights
      
      return {
        success: true,
        insights: insights.length > 0 ? insights : [
          "Insufficient data to generate meaningful insights",
          "Try querying a larger dataset or providing more specific context"
        ]
      };
    } catch (error) {
      console.error('AI insights generation error:', error.message);
      
      // Provide fallback insights
      return {
        success: true,
        insights: [
          "Error generating AI insights: " + error.message,
          "Housing violations data requires careful analysis to identify patterns",
          "Consider exploring correlations between violation types and building characteristics",
          "Temporal analysis may reveal seasonal patterns in housing issues"
        ]
      };
    }
  }
}

module.exports = AIService;
