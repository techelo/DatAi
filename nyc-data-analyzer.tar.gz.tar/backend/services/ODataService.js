const axios = require('axios');
const config = require('../config/default');

/**
 * Utility functions for OData operations
 */
class ODataService {
  /**
   * Test connection to an OData endpoint
   * @param {string} endpoint - The OData endpoint URL
   * @param {string} version - OData version (v2 or v4)
   * @returns {Promise} - Connection test result
   */
  static async testConnection(endpoint, version) {
    try {
      const response = await axios.get(endpoint, {
        headers: {
          Accept: version === 'v2' ? 'application/json' : 'application/json;odata.metadata=minimal'
        },
        timeout: 10000 // 10 seconds timeout
      });
      
      return {
        success: true,
        message: 'Successfully connected to OData endpoint',
        metadata: response.data
      };
    } catch (error) {
      console.error('OData connection error:', error.message);
      throw new Error(`Failed to connect to OData endpoint: ${error.message}`);
    }
  }
  
  /**
   * Query an OData endpoint
   * @param {string} endpoint - The OData endpoint URL
   * @param {string} version - OData version (v2 or v4)
   * @param {string} query - OData query parameters
   * @returns {Promise} - Query result
   */
  static async query(endpoint, version, query) {
    try {
      // Construct the query URL
      const queryUrl = query ? `${endpoint}?${query}` : endpoint;
      
      const response = await axios.get(queryUrl, {
        headers: {
          Accept: version === 'v2' ? 'application/json' : 'application/json;odata.metadata=minimal'
        },
        timeout: 30000 // 30 seconds timeout for potentially large queries
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      console.error('OData query error:', error.message);
      throw new Error(`Failed to query OData endpoint: ${error.message}`);
    }
  }
  
  /**
   * Get NYC OpenData datasets
   * @param {string} category - Optional category filter
   * @param {number} limit - Maximum number of datasets to return
   * @returns {Promise} - List of datasets
   */
  static async getNycDatasets(category = 'housing-development', limit = 100) {
    try {
      // NYC OpenData API endpoint for datasets
      const nycDatasetUrl = 'https://data.cityofnewyork.us/api/catalog/v1';
      
      const response = await axios.get(nycDatasetUrl, {
        params: {
          domains: category,
          limit: limit
        },
        timeout: 10000
      });
      
      // Extract relevant dataset information
      const datasets = response.data.results.map(dataset => ({
        id: dataset.resource.id,
        name: dataset.resource.name,
        description: dataset.resource.description,
        category: dataset.classification.domain_category,
        updatedAt: dataset.resource.updatedAt,
        permalink: dataset.permalink
      }));
      
      return {
        success: true,
        count: datasets.length,
        datasets
      };
    } catch (error) {
      console.error('NYC OpenData API error:', error.message);
      throw new Error(`Failed to fetch NYC OpenData datasets: ${error.message}`);
    }
  }
  
  /**
   * Convert natural language query to OData query
   * @param {string} naturalLanguage - Natural language query
   * @param {string} endpoint - The OData endpoint URL
   * @returns {string} - OData query string
   */
  static convertNaturalLanguageToODataQuery(naturalLanguage, endpoint) {
    // This is a simplified implementation
    // In a real application, this would use more sophisticated NLP
    
    // Extract key terms from the natural language query
    const lowercaseQuery = naturalLanguage.toLowerCase();
    
    // Basic mapping of common terms to OData query parameters
    let queryParts = [];
    
    // Filter by borough
    if (lowercaseQuery.includes('manhattan')) {
      queryParts.push("$filter=borough eq 'MANHATTAN'");
    } else if (lowercaseQuery.includes('brooklyn')) {
      queryParts.push("$filter=borough eq 'BROOKLYN'");
    } else if (lowercaseQuery.includes('queens')) {
      queryParts.push("$filter=borough eq 'QUEENS'");
    } else if (lowercaseQuery.includes('bronx')) {
      queryParts.push("$filter=borough eq 'BRONX'");
    } else if (lowercaseQuery.includes('staten island')) {
      queryParts.push("$filter=borough eq 'STATEN ISLAND'");
    }
    
    // Filter by violation type
    if (lowercaseQuery.includes('heat') || lowercaseQuery.includes('hot water')) {
      if (queryParts.length > 0) {
        queryParts[0] = queryParts[0] + " and contains(violation_description, 'HEAT')";
      } else {
        queryParts.push("$filter=contains(violation_description, 'HEAT')");
      }
    }
    
    // Limit results
    queryParts.push('$top=100');
    
    return queryParts.join('&');
  }
}

module.exports = ODataService;
