# User Guide: NYC Data Analyzer

## Introduction

Welcome to the NYC Data Analyzer, a powerful web application that combines OData connectivity with generative AI to help you analyze datasets, particularly those from NYC OpenData. This guide will walk you through all the features and functionality of the application.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Connecting to Data Sources](#connecting-to-data-sources)
3. [Dashboard Overview](#dashboard-overview)
4. [Using the AI Chat Interface](#using-the-ai-chat-interface)
5. [Map View](#map-view)
6. [Generating Reports](#generating-reports)
7. [Tips and Best Practices](#tips-and-best-practices)
8. [Troubleshooting](#troubleshooting)

## Getting Started

When you first open the NYC Data Analyzer, you'll see the main interface with a navigation bar at the top. The application has three main tabs:

- **NYC Data Analyzer**: The main application
- **Test Harness**: For testing functionality (primarily for developers)
- **Usability Testing**: For providing feedback on the application

For regular use, stay on the "NYC Data Analyzer" tab.

## Connecting to Data Sources

Before you can analyze data, you need to connect to an OData endpoint:

1. In the main view, you'll see a form to enter an OData endpoint
2. Enter the complete URL of the OData service (e.g., `https://services.odata.org/V4/Northwind/Northwind.svc/`)
3. Select the appropriate OData version (V2 or V4)
4. Click "Connect"

For NYC OpenData, you can use endpoints like:
- Housing Violations: `https://data.cityofnewyork.us/resource/wvxf-dwi5.json`
- DOB Violations: `https://data.cityofnewyork.us/resource/3h2n-5cm9.json`

Once connected, you'll see a success message and the application will load the data.

## Dashboard Overview

The Dashboard provides an overview of the connected dataset with:

- **Summary Cards**: Key statistics about the data
- **Charts and Graphs**: Visual representations of the data
- **AI-Generated Insights**: Automatically generated observations about patterns in the data

You can:
- View violations by borough
- See the distribution of violation types
- Track trends over time
- Read AI-generated insights about the data

## Using the AI Chat Interface

The AI Chat interface allows you to ask questions about the data in natural language:

1. Click on the "AI Chat" tab in the navigation
2. Type your question in the input field (e.g., "What are the most common violations in Brooklyn?")
3. Press Enter or click the send button
4. The AI will analyze the data and provide a response

Example questions you can ask:
- "Show me the trend of heat-related violations over the past year"
- "Which buildings have the most open violations?"
- "Compare violation rates between Manhattan and Brooklyn"
- "What percentage of violations are classified as critical?"

## Map View

The Map View provides a geographic visualization of the data:

1. Click on the "Map View" tab in the navigation
2. Use the filters to select the data type and severity
3. Hover over data points to see details
4. Use the summary panel to see statistics by borough and severity

The map shows:
- Data points color-coded by severity
- Borough boundaries
- Concentration of violations by area

## Generating Reports

The Reports feature allows you to create custom reports from the data:

1. Click on the "Reports" tab in the navigation
2. Configure your report settings:
   - Report Title
   - Report Type (Comprehensive, Summary, Violations, Trends)
   - Time Range
   - Include/exclude charts and AI insights
3. Preview the report in real-time
4. Click "Generate Report" to create the final report
5. Select your preferred export format (PDF, Excel, CSV)

## Tips and Best Practices

- **Refine Your Queries**: Be specific when asking questions in the AI Chat
- **Use Filters**: In Map View, use filters to focus on specific data types
- **Regular Updates**: Reconnect to the data source periodically to get the latest data
- **Save Reports**: Export important reports for future reference
- **Compare Data**: Use the AI to compare different boroughs or time periods

## Troubleshooting

**Connection Issues**:
- Verify the OData endpoint URL is correct
- Ensure you've selected the correct OData version
- Check your internet connection

**Slow Performance**:
- Try connecting to a more specific endpoint with less data
- Use filters to reduce the amount of data being processed
- Close other browser tabs to free up resources

**AI Chat Not Responding**:
- Ensure your questions are clear and specific
- Try rephrasing your question
- Reconnect to the data source

**Report Generation Errors**:
- Try selecting a smaller time range
- Disable some charts if the report is too complex
- Use a different export format

If you continue to experience issues, please contact support with details about the problem you're encountering.
