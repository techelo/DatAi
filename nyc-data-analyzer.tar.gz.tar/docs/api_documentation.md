# API Documentation: NYC Data Analyzer

This document provides detailed information about the backend API endpoints available in the NYC Data Analyzer application.

## Base URL

All API endpoints are relative to the base URL of the server:

```
http://localhost:5000/api
```

## Authentication

Currently, the API does not require authentication. This may change in future versions.

## API Endpoints

### OData Routes

#### Test OData Connection

Tests the connection to an OData endpoint.

- **URL**: `/odata/test`
- **Method**: `GET`
- **Query Parameters**:
  - `endpoint` (required): The OData endpoint URL
  - `version` (optional): OData version ('v2' or 'v4'), defaults to 'v4'
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "message": "Successfully connected to OData endpoint",
      "metadata": { ... }
    }
    ```
- **Error Response**:
  - **Code**: 400/500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  GET /api/odata/test?endpoint=https://services.odata.org/V4/Northwind/Northwind.svc/&version=v4
  ```

#### Query OData Endpoint

Executes a query against an OData endpoint.

- **URL**: `/odata/query`
- **Method**: `GET`
- **Query Parameters**:
  - `endpoint` (required): The OData endpoint URL
  - `version` (optional): OData version ('v2' or 'v4'), defaults to 'v4'
  - `query` (optional): OData query string
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "data": { ... }
    }
    ```
- **Error Response**:
  - **Code**: 400/500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  GET /api/odata/query?endpoint=https://services.odata.org/V4/Northwind/Northwind.svc/Products&version=v4&query=$top=10
  ```

#### Get NYC OpenData Datasets

Retrieves a list of available datasets from NYC OpenData.

- **URL**: `/odata/nyc/datasets`
- **Method**: `GET`
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "count": 100,
      "datasets": [ ... ]
    }
    ```
- **Error Response**:
  - **Code**: 500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  GET /api/odata/nyc/datasets
  ```

### AI Routes

#### Process Chat Messages

Processes chat messages with Hugging Face AI.

- **URL**: `/ai/chat`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "messages": [
      {
        "sender": "user",
        "text": "What are the most common violations in Brooklyn?"
      }
    ],
    "odataEndpoint": "https://data.cityofnewyork.us/resource/wvxf-dwi5.json"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "response": {
        "text": "Based on the data, the most common violations in Brooklyn are...",
        "type": "text"
      }
    }
    ```
- **Error Response**:
  - **Code**: 400/500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  POST /api/ai/chat
  ```

#### Analyze Data

Analyzes data from an OData endpoint using AI.

- **URL**: `/ai/analyze`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "endpoint": "https://data.cityofnewyork.us/resource/wvxf-dwi5.json",
    "version": "v4",
    "query": "$filter=borough eq 'BROOKLYN'",
    "question": "What patterns do you see in these violations?"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "analysis": {
        "text": "The analysis of the data shows several patterns...",
        "type": "text",
        "dataCount": 1000
      }
    }
    ```
- **Error Response**:
  - **Code**: 400/500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  POST /api/ai/analyze
  ```

### Test Routes (For Development)

#### Get Test Data

Retrieves test data for the application.

- **URL**: `/test/data`
- **Method**: `GET`
- **Query Parameters**:
  - `dataset` (required): The dataset to retrieve ('housingViolations', 'dobViolations', 'plutoData')
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "data": { ... }
    }
    ```
- **Error Response**:
  - **Code**: 400/500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  GET /api/test/data?dataset=housingViolations
  ```

#### Test OData Endpoint

Tests the OData endpoint with sample data.

- **URL**: `/test/odata`
- **Method**: `GET`
- **Query Parameters**:
  - `dataset` (optional): The dataset to use for testing
- **Success Response**:
  - **Code**: 200
  - **Content**: 
    ```json
    {
      "success": true,
      "message": "Successfully connected to test OData endpoint",
      "metadata": { ... }
    }
    ```
- **Error Response**:
  - **Code**: 500
  - **Content**: 
    ```json
    {
      "success": false,
      "message": "Error message",
      "error": "Detailed error information"
    }
    ```
- **Example**:
  ```
  GET /api/test/odata?dataset=housingViolations
  ```

## Error Handling

All API endpoints follow a consistent error handling pattern:

- **400 Bad Request**: Invalid input parameters
- **404 Not Found**: Resource not found
- **500 Internal Server Error**: Server-side error

Error responses include:
- `success`: Boolean indicating success (always `false` for errors)
- `message`: Human-readable error message
- `error`: Detailed error information (when available)

## Rate Limiting

Currently, there are no rate limits implemented. This may change in future versions.

## Data Models

### Housing Violations

```json
{
  "violationid": 11152656,
  "buildingid": 826503,
  "borough": "BROOKLYN",
  "housenumber": "123",
  "streetname": "MAIN STREET",
  "zip": "11201",
  "apartment": "3A",
  "class": "C",
  "inspectiondate": "2023-01-15T00:00:00.000Z",
  "novdescription": "SECTION 27-2005 ADMIN CODE REPAIR THE BROKEN OR DEFECTIVE PLASTERED SURFACES",
  "currentstatus": "OPEN"
}
```

### DOB Violations

```json
{
  "violationid": 20230001,
  "buildingid": 826503,
  "borough": "BROOKLYN",
  "housenumber": "123",
  "streetname": "MAIN STREET",
  "zip": "11201",
  "violationtype": "ELEVATOR",
  "violationcategory": "SAFETY",
  "violationstatus": "ACTIVE",
  "issuedate": "2023-01-10T00:00:00.000Z",
  "description": "FAILURE TO MAINTAIN ELEVATOR IN SAFE OPERATING CONDITION"
}
```

### PLUTO Data

```json
{
  "bbl": 1012340056,
  "borough": "MANHATTAN",
  "block": 1234,
  "lot": 56,
  "address": "456 PARK AVENUE",
  "zipcode": "10022",
  "landusedesc": "RESIDENTIAL",
  "bldgclassdesc": "ELEVATOR APARTMENTS",
  "numfloors": 12,
  "unitsres": 48,
  "yearbuilt": 1965
}
```
