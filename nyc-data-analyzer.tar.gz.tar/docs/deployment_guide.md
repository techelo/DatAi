# Deployment Guide: NYC Data Analyzer

This document provides instructions for deploying the NYC Data Analyzer application to various environments.

## Table of Contents

1. [Local Deployment](#local-deployment)
2. [Heroku Deployment](#heroku-deployment)
3. [Docker Deployment](#docker-deployment)
4. [Environment Variables](#environment-variables)
5. [Production Considerations](#production-considerations)

## Local Deployment

### Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

### Steps

1. Clone the repository
```bash
git clone https://github.com/yourusername/nyc-data-analyzer.git
cd nyc-data-analyzer
```

2. Install all dependencies (backend and frontend)
```bash
npm run install-all
```

3. Create a `.env` file in the root directory with the required environment variables (see [Environment Variables](#environment-variables) section)

4. Build the frontend
```bash
npm run build
```

5. Start the production server
```bash
npm start
```

The application will be available at `http://localhost:5000`

## Heroku Deployment

### Prerequisites

- Heroku CLI installed
- Heroku account

### Steps

1. Login to Heroku
```bash
heroku login
```

2. Create a new Heroku app
```bash
heroku create nyc-data-analyzer
```

3. Set the required environment variables
```bash
heroku config:set NODE_ENV=production
heroku config:set HUGGING_FACE_API_KEY=your_hugging_face_api_key
```

4. Push to Heroku
```bash
git push heroku main
```

5. Open the deployed application
```bash
heroku open
```

The application is configured with a `heroku-postbuild` script that will automatically install dependencies and build the frontend.

## Docker Deployment

### Prerequisites

- Docker installed
- Docker Compose (optional, for multi-container setup)

### Steps

1. Build the Docker image
```bash
docker build -t nyc-data-analyzer .
```

2. Run the container
```bash
docker run -p 5000:5000 --env-file .env nyc-data-analyzer
```

The application will be available at `http://localhost:5000`

## Environment Variables

The following environment variables are required for the application:

| Variable | Description | Default |
|----------|-------------|---------|
| PORT | Port for the server to listen on | 5000 |
| NODE_ENV | Environment (development/production) | development |
| HUGGING_FACE_API_KEY | API key for Hugging Face | - |
| NYC_OPENDATA_APP_TOKEN | App token for NYC OpenData (optional) | - |

## Production Considerations

### Security

- Ensure HTTPS is enabled for production deployments
- Set up proper CORS configuration in `backend/server.js` for your production domain
- Consider implementing rate limiting for API endpoints
- Add authentication if deploying to a public environment

### Performance

- Enable compression for Express
- Consider implementing a CDN for static assets
- Set up proper caching headers
- Monitor memory usage and implement garbage collection if needed

### Monitoring

- Set up logging (consider using Winston or similar)
- Implement error tracking (Sentry, Rollbar, etc.)
- Set up performance monitoring
- Configure alerts for critical errors

### Scaling

- Consider using a process manager like PM2
- For high traffic, consider horizontal scaling with load balancing
- Implement database caching if adding a database in the future
